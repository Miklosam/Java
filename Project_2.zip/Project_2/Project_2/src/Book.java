
public class Book {
	public String isbn;
	
	public Book(String isbn) {
		this.isbn = isbn;
	}
}
