
public class BookShipment {
	public Book book;
	public Integer shipmentQuantity;
	
	public BookShipment(Book book, Integer shipmentQuantity) {
		this.book = book;
		this.shipmentQuantity = shipmentQuantity;
	}
}
